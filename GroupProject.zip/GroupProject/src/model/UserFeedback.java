package model;

import java.util.ArrayList;

public class UserFeedback extends SmartSerializable
{
	private static final long serialVersionUID = 1L;
	
	public String messageID;
	public String firstname;
	public String lastname;
	public String country;
	public String message;
	
	
	
	

}



